history_id=['00000001', '00000002', '00000003', '00000004']
history_description=['admin tried to use a curse word knwon as: cock', 'admin tried to use a curse word knwon as: cock', 'Incorrect Password', 'Incorrect Password']
count=5