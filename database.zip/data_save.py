active_users=[True, True, True, True]
denied_inputs=['', ' ', None]
data_bases=[['tools', True, 'all', 'column_row', ['name', 'id']]]
row=[]
lists=[]
known_users=['admin', 'brandon', 'abdullahi', 'tripp']
passwords=['admin', 'Hello', 'snake', 'solid']
permissions=['admin', 'admin', 'admin', 'admin']
global_password=True
allowed_types=['column_row', 'list', 'grid']
allowed_users=['admin', 'student', 'teacher']
min_length=5
max_length=8
debug=True
opto_data=[]
opto_row=[]
opto_lists=[]

